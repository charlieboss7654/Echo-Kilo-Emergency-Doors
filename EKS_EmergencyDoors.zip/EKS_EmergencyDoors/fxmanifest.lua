fx_version 'cerulean'
game 'gta5'

lua54 'yes'

name 'EKS_EmergencyDoors'
author 'Cowboy - Echo Kilo Studios'
version '1.0.0'

shared_script 'shared/config.lua'

client_scripts {
    'client/client.lua'
}

server_script 'server/server.lua'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/sounds/*.ogg'
}

dependencies {
    'ox_target'
}
