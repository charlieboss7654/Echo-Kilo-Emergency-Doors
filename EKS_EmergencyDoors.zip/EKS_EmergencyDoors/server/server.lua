RegisterNetEvent('eks:worldShutterSound', function(soundName, vehNetId)
    TriggerClientEvent('eks:clientWorldShutterSound', -1, soundName, vehNetId)
end)
