local fireState = {}
local ambState  = {}

local function playLocalShutterSound(soundName, volume)
    SendNUIMessage({
        action = "playSound",
        sound  = soundName,
        volume = volume or 1.0
    })
end

RegisterNetEvent('eks:clientWorldShutterSound', function(soundName, vehNetId)
    local veh = NetToVeh(vehNetId)
    if veh == 0 or not DoesEntityExist(veh) then return end

    local ped = PlayerPedId()
    local pedCoords = GetEntityCoords(ped)
    local vehCoords = GetEntityCoords(veh)

    local maxDist = Config.SoundMaxDistance or 20.0
    local dist = #(pedCoords - vehCoords)

    if dist > maxDist then return end

    local volume = 1.0 - (dist / maxDist)
    if volume < 0.0 then volume = 0.0 end

    playLocalShutterSound(soundName, volume)
end)

local function triggerWorldShutterSound(soundName, veh)
    local vehNetId = NetworkGetNetworkIdFromEntity(veh)
    if vehNetId and vehNetId ~= 0 then
        TriggerServerEvent('eks:worldShutterSound', soundName, vehNetId)
    else
        playLocalShutterSound(soundName, 1.0)
    end
end

local function playAnim(anim)
    if not anim then return end

    local ped = PlayerPedId()

    RequestAnimDict(anim.dict)
    while not HasAnimDictLoaded(anim.dict) do
        Wait(0)
    end

    TaskPlayAnim(
        ped,
        anim.dict,
        anim.name,
        8.0,
        -8.0,
        anim.duration or -1,
        anim.flag or 49,
        0.0,
        false,
        false,
        false
    )
end

local function getVehId(veh)
    if not DoesEntityExist(veh) then return nil end
    return NetworkGetNetworkIdFromEntity(veh)
end

local function toggleFireShutters(vehicleInfo, opening, veh)
    if vehicleInfo.type == "doors" then
        for _, door in ipairs(vehicleInfo.doors or {}) do
            if opening then
                SetVehicleDoorOpen(veh, door, false, false)
            else
                SetVehicleDoorShut(veh, door, false)
            end
        end
    elseif vehicleInfo.type == "extra" then
        if vehicleInfo.shutterExtra then
            if type(vehicleInfo.shutterExtra) == "table" then
                for _, extraId in ipairs(vehicleInfo.shutterExtra) do
                    SetVehicleExtra(veh, extraId, opening and 0 or 1)
                end
            else
                SetVehicleExtra(veh, vehicleInfo.shutterExtra, opening and 0 or 1)
            end
        end

        if vehicleInfo.optionalExtraOnOpen then
            SetVehicleExtra(veh, vehicleInfo.optionalExtraOnOpen, opening and 0 or 1)
        end
    end

    triggerWorldShutterSound(opening and "shutters_open" or "shutters_close", veh)
end

local function toggleAmbulanceDoors(vehicleInfo, opening, veh)
    for _, door in ipairs(vehicleInfo.doors or {}) do
        if opening then
            SetVehicleDoorOpen(veh, door, false, false)
        else
            SetVehicleDoorShut(veh, door, false)
        end
    end
end

CreateThread(function()
    local dist = Config.TargetDistance or 1.8

    for _, v in ipairs(Config.FireVehicles or {}) do
        local offsets = v.offsets or {}

        if #offsets == 0 then
            print(("[EKS_EmergencyDoors] No offsets configured for fire vehicle model %s, skipping target."):format(tostring(v.model)))
        else
            local options = {}

            for idx, off in ipairs(offsets) do
                local thisOffset = off

                options[#options+1] = {
                    name     = ('eks_open_shutters_%s_%d'):format(tostring(v.model), idx),
                    label    = 'Open Shutters',
                    icon     = 'fa-solid fa-door-open',
                    distance = dist * 2.0,
                    onSelect = function(data)
                        local veh = data.entity
                        if not DoesEntityExist(veh) then return end

                        local id = getVehId(veh)
                        fireState[id] = true

                        playAnim(v.animOpen)
                        toggleFireShutters(v, true, veh)
                    end,
                    canInteract = function(entity, distance)
                        if distance > dist * 2.0 then return false end
                        local ped = PlayerPedId()
                        local pedCoords = GetEntityCoords(ped)
                        local localPos = GetOffsetFromEntityGivenWorldCoords(entity, pedCoords.x, pedCoords.y, pedCoords.z)
                        local d = #(localPos - thisOffset)
                        if d > dist then return false end
                        local id = getVehId(entity)
                        return not fireState[id]
                    end
                }

                options[#options+1] = {
                    name     = ('eks_close_shutters_%s_%d'):format(tostring(v.model), idx),
                    label    = 'Close Shutters',
                    icon     = 'fa-solid fa-door-closed',
                    distance = dist * 2.0,
                    onSelect = function(data)
                        local veh = data.entity
                        if not DoesEntityExist(veh) then return end

                        local id = getVehId(veh)
                        fireState[id] = false

                        playAnim(v.animClose)
                        toggleFireShutters(v, false, veh)
                    end,
                    canInteract = function(entity, distance)
                        if distance > dist * 2.0 then return false end
                        local ped = PlayerPedId()
                        local pedCoords = GetEntityCoords(ped)
                        local localPos = GetOffsetFromEntityGivenWorldCoords(entity, pedCoords.x, pedCoords.y, pedCoords.z)
                        local d = #(localPos - thisOffset)
                        if d > dist then return false end
                        local id = getVehId(entity)
                        return fireState[id]
                    end
                }
            end

            exports.ox_target:addModel(v.model, options)
        end
    end

    for _, a in ipairs(Config.AmbulanceVehicles or {}) do
        local offsets = a.offsets or {}

        if #offsets == 0 then
            print(("[EKS_EmergencyDoors] No offsets configured for ambulance model %s, skipping target."):format(tostring(a.model)))
        else
            local options = {}

            for idx, off in ipairs(offsets) do
                local thisOffset = off

                options[#options+1] = {
                    name     = ('eks_open_rear_%s_%d'):format(tostring(a.model), idx),
                    label    = 'Open Doors',
                    icon     = 'fa-solid fa-door-open',
                    distance = dist * 2.0,
                    onSelect = function(data)
                        local veh = data.entity
                        if not DoesEntityExist(veh) then return end

                        local id = getVehId(veh)
                        ambState[id] = true

                        playAnim(a.animOpen)
                        toggleAmbulanceDoors(a, true, veh)
                    end,
                    canInteract = function(entity, distance)
                        if distance > dist * 2.0 then return false end
                        local ped = PlayerPedId()
                        local pedCoords = GetEntityCoords(ped)
                        local localPos = GetOffsetFromEntityGivenWorldCoords(entity, pedCoords.x, pedCoords.y, pedCoords.z)
                        local d = #(localPos - thisOffset)
                        if d > dist then return false end
                        local id = getVehId(entity)
                        return not ambState[id]
                    end
                }

                options[#options+1] = {
                    name     = ('eks_close_rear_%s_%d'):format(tostring(a.model), idx),
                    label    = 'Close Doors',
                    icon     = 'fa-solid fa-door-closed',
                    distance = dist * 2.0,
                    onSelect = function(data)
                        local veh = data.entity
                        if not DoesEntityExist(veh) then return end

                        local id = getVehId(veh)
                        ambState[id] = false

                        playAnim(a.animClose)
                        toggleAmbulanceDoors(a, false, veh)
                    end,
                    canInteract = function(entity, distance)
                        if distance > dist * 2.0 then return false end
                        local ped = PlayerPedId()
                        local pedCoords = GetEntityCoords(ped)
                        local localPos = GetOffsetFromEntityGivenWorldCoords(entity, pedCoords.x, pedCoords.y, pedCoords.z)
                        local d = #(localPos - thisOffset)
                        if d > dist then return false end
                        local id = getVehId(entity)
                        return ambState[id]
                    end
                }
            end

            exports.ox_target:addModel(a.model, options)
        end
    end
end)

local vehicleCoordMode = false
local vehicleCoordVeh  = nil

local function rotationToDirection(rot)
    local z = math.rad(rot.z)
    local x = math.rad(rot.x)
    local num = math.abs(math.cos(x))
    return vector3(
        -math.sin(z) * num,
         math.cos(z) * num,
         math.sin(x)
    )
end

local function raycastFromCamera(maxDistance)
    local camPos = GetGameplayCamCoord()
    local camRot = GetGameplayCamRot(2)
    local dir = rotationToDirection(camRot)
    local dest = camPos + dir * maxDistance

    local rayHandle = StartShapeTestRay(
        camPos.x, camPos.y, camPos.z,
        dest.x, dest.y, dest.z,
        -1,
        PlayerPedId(),
        0
    )

    local _, hit, endCoords, _, entityHit = GetShapeTestResult(rayHandle)
    return hit == 1, endCoords, entityHit
end

RegisterCommand('vehiclecoords', function()
    if vehicleCoordMode then
        vehicleCoordMode = false
        vehicleCoordVeh  = nil
        return
    end

    local ped = PlayerPedId()
    local pos = GetEntityCoords(ped)
    local veh = GetClosestVehicle(pos.x, pos.y, pos.z, 8.0, 0, 70)

    if veh == 0 or not DoesEntityExist(veh) then
        TriggerEvent('chat:addMessage', {
            color = { 255, 0, 0 },
            multiline = true,
            args = { 'EKS', 'No vehicle nearby to sample coordinates from.' }
        })
        return
    end

    vehicleCoordMode = true
    vehicleCoordVeh  = veh

    TriggerEvent('chat:addMessage', {
        color = { 0, 200, 255 },
        multiline = true,
        args = {
            'EKS',
            'Vehicle coord mode: aim at the vehicle and left-click to get an offset. Press BACKSPACE to cancel.'
        }
    })

    CreateThread(function()
        while vehicleCoordMode do
            Wait(0)

            BeginTextCommandDisplayHelp('STRING')
            AddTextComponentSubstringPlayerName('Aim at the vehicle and left-click to capture an offset.\nPress BACKSPACE to cancel.')
            EndTextCommandDisplayHelp(0, false, true, -1)

            if IsControlJustPressed(0, 24) then
                local hit, hitCoords, entityHit = raycastFromCamera(10.0)
                if hit and entityHit == vehicleCoordVeh then
                    local offset = GetOffsetFromEntityGivenWorldCoords(
                        vehicleCoordVeh,
                        hitCoords.x, hitCoords.y, hitCoords.z
                    )

                    local msg = string.format(
                        'Offset: vector3(%.3f, %.3f, %.3f)',
                        offset.x, offset.y, offset.z
                    )

                    print('[EKS_EmergencyDoors] ' .. msg)

                    TriggerEvent('chat:addMessage', {
                        color = { 0, 255, 0 },
                        multiline = true,
                        args = { 'EKS', msg .. '  (copy this into your config offsets)' }
                    })

                    vehicleCoordMode = false
                    vehicleCoordVeh  = nil
                else
                    TriggerEvent('chat:addMessage', {
                        color = { 255, 150, 0 },
                        multiline = true,
                        args = { 'EKS', 'Could not detect a hit on that vehicle. Aim directly at the bodywork and try again.' }
                    })
                end
            elseif IsControlJustPressed(0, 177) then
                vehicleCoordMode = false
                vehicleCoordVeh  = nil
            end
        end
    end)
end, false)
