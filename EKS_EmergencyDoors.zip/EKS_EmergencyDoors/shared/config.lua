Config = {}

Config.TargetDistance    = 1.8   -- interaction radius around each offset (meters)
Config.SoundMaxDistance  = 20.0  -- how far shutter sounds can be heard


-- FIRE APPLIANCES (SHUTTERS)
-- type:
--   "doors"  ? uses doors = { doorIds }
--   "extra"  ? uses shutterExtra = X or { X, Y, Z }
--
-- shutterExtra:
--   number   ? single extra
--   {table}  ? multiple extras
--
-- optionalExtraOnOpen:
--   single extra ID that is enabled only while shutters are open
--
-- offsets:
--   local vehicle offsets for third-eye positions
--   use /vehiclecoords to generate these for each model

Config.FireVehicles = {
    {
        model = `NBPOPPY`,
        type  = "extra",

        doors              = nil,
        shutterExtra       = 11,
        optionalExtraOnOpen = 12,

        animOpen  = nil,
        animClose = nil,

        offsets = {
            vector3(-1.150, -0.008, 1.016),
            vector3(1.154, -1.871, 0.983)
        }
    }

    -- add more fire vehicles here if needed
}


-- AMBULANCES (REAR DOORS)
-- doors:
--   rear door indexes (usually 2 and 3)
--
-- offsets:
--   local offsets at the back of the ambulance

Config.AmbulanceVehicles = {
    {
        model = `ambulance`,
        doors = { 2, 3 },

        animOpen  = nil,
        animClose = nil,

        offsets = {
            vector3(0.132, -3.857, 0.585)
        }
    }

    -- add more ambulance models here if needed
}
